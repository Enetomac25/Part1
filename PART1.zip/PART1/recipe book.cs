﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PART1
{
    public class recipeBook

    {
        private string ingredientNames;
        private double ingredientQuantities;
        private string ingredientUnits;
    }
   



}
