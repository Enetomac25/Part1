﻿namespace PART1
{
   public class Program
    {
        private static int i;
        private static int numSteps;
     
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to  Recipe Book");
            Console.WriteLine("Please enter the details for your recipe");

            //Get number of ingredients
            Console.Write("\nHow many ingredients are in the recipe?");
            int numIngredients= int.Parse(Console.ReadLine());

            //Get details for each ingredient
            string[] ingredientNames = new string[numIngredients];
            Double[] Quantities = new Double[numIngredients];
            string[] Units= new string[numIngredients];

            for (int i = 0; i < numIngredients; i++);
            {

                Console.WriteLine($"\nImgredient{i + 1}");

                Console.WriteLine("Eneter the name of ingredient");
                ingredientNames[i] = Console.ReadLine();

                Console.WriteLine("Enter the quantity of ingredient");
                Quantities[i] = double.Parse(Console.ReadLine());

                Console.WriteLine("Enter the units of measurement of ingredient");
                Units[i] = Console.ReadLine();
            }
            //Get number of steps
            Console.Write("Enter the number of steps");
           int numSteps= int.Parse(Console.ReadLine());

            //Get detail for each steps
            string[]steps= new string[numSteps];
            for (int i = 0; i < numSteps; i++) ;
            Console.WriteLine((i + 1) + "." + steps[i]);
            {
                Console.WriteLine($"\nSteps {i +1}:");
                Console.Write("Enter the Description of step");
                steps[i] = Console.ReadLine();
             }
            Console.WriteLine("Ingredients:");
            for (int i = 0;i < numIngredients; i++)
            {
                Console.WriteLine(Quantities[i]+""+ Units + ingredientNames[i] );
            }
            Console.WriteLine("Steps");
            for (int i = 0; i < numSteps; i++) ;
            Console.WriteLine((i + 1) + "." + steps[i]);
            {
                Console.WriteLine("Enter the factor by which you want to scale the recipe");
                 double factor= double.Parse(Console.ReadLine());
                for(int i = 0;i<numIngredients;i++)
                {
                    Quantities[i]*=factor;
                }
            }
            Console.WriteLine("ingredient");
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine(Quantities[i]+""+Units + ingredientNames[i] );
            }
            Console.WriteLine("Steps");
            for (int i = 0;i< numSteps;i++)
                Console.WriteLine((i + 1) + "." + steps[i]);
            {
               Console.WriteLine("Enter the factoe by which you want to reset the recipe");
                double factor = double.Parse(Console.ReadLine());
                for (int j = 0; i < numIngredients; i++) ;
                {
                    Quantities[i]/=factor;
                }

                Console.WriteLine("Ingredients");
                for (int i = 0; i < numIngredients; i++) ;
                {
                    Console.WriteLine(Quantities[i]+""+Units+ ingredientNames);
                }
                Console.WriteLine("steps:");
                for (int i = 0; i < numIngredients; i++) ;
                {
                    Console.WriteLine((i + 1) + "." + steps[i]);
                }
            }
            Console.WriteLine("Enter the number of ingredients");
            numIngredients = int.Parse(Console.ReadLine());
            ingredientNames = new string[numIngredients];
            Quantities= new double[numIngredients];
            Units= new string[numIngredients];
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine("Enter the name of ingredients" + (i + 1) + ":");
                ingredientNames[i] = Console.ReadLine();
                Console.WriteLine("Enter the quantity of ingrediant" + (i + 1) + ":");
                Quantities[i]= double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the unit measurement of ingredient" + (i + 1) + ":");
                Units[i] = Console.ReadLine();
            }
            Console.WriteLine("Enter the number of steps:");
            numSteps = int.Parse(Console.ReadLine());
            steps = new string[numSteps];
            for (int i = 0; i<numSteps; i++)
            {
                Console.WriteLine("Enter the description of step"+(i+1)+":");
                steps[i] = Console.ReadLine();

            }

            //Display recipe

            Console.WriteLine("\nHere is your recipe");

            Console.WriteLine("Ingredients:");
            for(int i = 0;i < numIngredients; i++)   
            {
            Console.WriteLine("_" + Quantities[i] +""+
             Units[i]+ "of"+
             ingredientNames[i]);
            }
            Console.WriteLine("\nSteps:");
            for(int i=0;i<numSteps;i++)
            { 
                Console.WriteLine((i+1) + "." + steps[i]);
            }
            Console.ReadLine();

            static double NewMethod()
            {
                return double.Parse(s: Console.ReadLine());
            }

        }
    }
}