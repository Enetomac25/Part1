﻿internal static class ProgramHelpers
{
}